from django import forms
class userForm(forms.Form):
    num1=forms.CharField()
    num2=forms.CharField()