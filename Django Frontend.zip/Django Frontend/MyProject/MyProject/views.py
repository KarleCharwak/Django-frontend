from django.http import HttpResponse
from django.shortcuts import render
from .forms import userForm
def aboutus(request):
    return HttpResponse("Welcome to the website")
def Course(request):
    return HttpResponse("wlecome to Courses")
def CourseDetails(request,courseid):
    return HttpResponse(courseid)
def homepage(request):
    data = {
        'title':"home__page",
        'bdata':"welcome to the website",
        'list':['php','java','javascript'],
        'student_details':[{'name':"Arjun",'phone':"9561234895"},
                            {'name':"Ashok",'phone':"9765412395"}],
        'numbers':[10,20,30,40,50,90,100]
    }
    return render(request,"index.html",data)

# def userForm(request):
#     finalans=0
#     try:
#         # n1=int(request.GET['num1'])
#         n1=int(request.POST.get('num1'))
#         n2=int(request.GET['num2'])
#         finalans=n1+n2
#     except:
#         pass
#     return render(request,'userform.html',{'output':finalans})

def userForm(request):
    finalans=0
    # fn=userForm()

    # data={'form':fn}
    try:
        if request.method=="POST":
            n1 = int(request.POST.get('num1'))
            n2 = int(request.POST.get('num2'))
            finalans = n1+n2
            # data = {
            #     'form':fn,
            #     'output':finalans
            # }
            # url="/about-us/?output={}".formal(finalans)

            # return redirect(url)
    except:
        pass

    return render(request,"userform.html",{'output':finalans})